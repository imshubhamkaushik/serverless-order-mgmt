import json
import boto3
import os
import logging
from decimal import Decimal

logger = logging.getLogger()
logger.setLevel(logging.INFO)

dynamodb = boto3.resource("dynamodb")
table = dynamodb.Table(os.environ["ORDERS_TABLE"])

class DecimalEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, Decimal):
            return int(obj) if obj % 1 == 0 else float(obj)
        return super().default(obj)
    
def response(status, body):
    return {
        "statusCode": status,
        "headers": {"Content-Type": "application/json"},
        "body": json.dumps(body, cls=DecimalEncoder)
    }
    
def handler(event, context):
    try:
        path_params = event.get("pathParameters") or {}
        order_id = path_params.get("id")

        if not isinstance(order_id, str) or not order_id.strip():
            return response(400, {"error": "Missing order id in path"})
        if len(order_id) > 100:
            return response(400, {"error": "order_id is too long"})
        
        logger.info(json.dumps({
            "message": "Fetching order",
            "order_id": order_id
        }))

        res = table.get_item(
            Key={"order_id": order_id},
            ConsistentRead=True
        )
        
        item = res.get("Item")

        if not item:
            return response(404, {"message": "Order not found"})

        return response(200, item)

    except Exception:
        logger.error("Get order failed", exc_info=True)
        return response(500, {"error": "Internal server error"})
